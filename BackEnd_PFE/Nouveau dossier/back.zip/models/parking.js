const mongoose = require('mongoose');
const { fileLoader } = require('ejs');


const Schema = mongoose.Schema;


const parkSchema = new Schema({
    name: String,
    latitude: String,
    longitude: String,
    price: Number,
    nbplace: String,
    capteur: [{ firstName: String, lastName: String,reservation:Boolean }],
    image: String,
    userId:String,
    reservation: [{ type: Schema.Types.ObjectId, ref: 'listRes' }]

});

module.exports = mongoose.model('parking', parkSchema, 'parking');